<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis earum ipsa ea voluptatum magni amet laborum? Id quos, voluptatibus eveniet, tenetur quidem exercitationem deserunt esse corrupti in dolores, ipsa saepe.</p>

        </div>
    </div>
</div>
<?= $this->endSection(); ?>